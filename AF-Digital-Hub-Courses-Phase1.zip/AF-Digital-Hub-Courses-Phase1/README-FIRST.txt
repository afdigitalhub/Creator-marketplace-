AF DIGITAL HUB — COURSES PHASE 1

This package adds the professional course engine alongside the existing platform.

NEW BACKEND
- backend/routes/courses.js
- backend/migrations/001_courses.sql
- backend/migrations/002_seed_ghostwriting.sql

NEW FRONTEND
- frontend/courses.html
- frontend/course-details.html
- frontend/course-learn.html
- frontend/my-learning.html

UPDATED FRONTEND/BACKEND
- backend/server.js — mounts /courses
- frontend/index.html — Courses added to public navigation
- frontend/dashboard.html — Courses + My Learning added near the top of the hamburger menu; course/affiliate summary added without replacing the existing dashboard

DATABASE ORDER
1. Run 001_courses.sql in Neon.
2. Create/publish an existing product named "Ghostwriting Masterclass" (recommended price GHS 100; keep it within your course pricing limit).
3. Run 002_seed_ghostwriting.sql. It creates the Ghostwriting course and all 10 modules / 18 lessons from the prepared manuscript.

IMPORTANT
Do NOT replace orders.js, payments.js, products.js, or existing Paystack/R2/domain/Render configuration with this package.
This phase deliberately builds on the existing working order/payment/earnings architecture.
