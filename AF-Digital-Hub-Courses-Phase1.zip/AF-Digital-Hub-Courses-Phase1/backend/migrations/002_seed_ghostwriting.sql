BEGIN;

DO $$
DECLARE
  v_product_id INTEGER;
  v_course_id BIGINT;
  v_module_id BIGINT;
BEGIN
  SELECT id INTO v_product_id FROM products WHERE lower(title) = lower('Ghostwriting Masterclass') ORDER BY id DESC LIMIT 1;
  IF v_product_id IS NULL THEN
    RAISE EXCEPTION 'Create/publish a product named Ghostwriting Masterclass first, then run this seed.';
  END IF;

  INSERT INTO courses (product_id, title, slug, short_description, description, level, status, created_by)
  SELECT v_product_id,
         'Ghostwriting: Turn Other People''s Ideas Into Words That Sound Like Them',
         'ghostwriting-turn-ideas-into-words',
         'Learn how to turn another person''s ideas, experience and message into clear writing that still sounds like them.',
         'A practical course covering voice, client interviews, content structure, client work, pricing, outreach, confidentiality and building a real ghostwriting service.',
         'beginner', 'published', p.seller_id
    FROM products p
   WHERE p.id = v_product_id
  ON CONFLICT (product_id) DO UPDATE SET
    title = EXCLUDED.title,
    short_description = EXCLUDED.short_description,
    description = EXCLUDED.description,
    level = EXCLUDED.level,
    status = EXCLUDED.status,
    updated_at = now()
  RETURNING id INTO v_course_id;

  INSERT INTO course_modules (course_id, title, description, position) VALUES (v_course_id, 'Understanding Ghostwriting', 'Practical lessons from the AF Digital Hub Ghostwriting course.', 1) ON CONFLICT (course_id, position) DO UPDATE SET title=EXCLUDED.title, updated_at=now() RETURNING id INTO v_module_id;
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'What Ghostwriting Really Is', 'what-ghostwriting-really-is', 'Ghostwriting is writing on behalf of another person.

That sounds simple, but the difference between ordinary writing and good ghostwriting is important.

When you write your own article, you naturally use your own vocabulary, rhythm, humour, opinions, and personality.

When you ghostwrite, those things belong to somebody else.

Your job is to make the final piece sound like the client could have written it themselves.

That means the strongest ghostwriter is often the person who knows when **not** to show off.

A client may use short sentences. They may repeat certain phrases. They may prefer direct language. They may tell stories before making their point.

You don''t automatically "improve" those habits.

You first understand them.

### Practical exercise

Choose someone you know well.

Write down:

- Three phrases they commonly use.
- Whether they speak formally or casually.
- Whether they tell stories or get straight to the point.
- How they express disagreement.
- Whether they use humour.
- Whether they prefer short or detailed explanations.

You have just started building a voice profile.

---', 'text', 1, true) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Why People Hire Ghostwriters', 'why-people-hire-ghostwriters', 'People hire ghostwriters for many different reasons.

A business owner may know exactly what they want to say but have no time to write it.

A coach may have years of experience but struggle to turn that knowledge into a book.

An executive may want to publish regularly but cannot sit down every week to write.

A creator may have ideas constantly but need someone to turn those ideas into finished content.

The opportunity is not simply "I can write."

The stronger offer is:

**"Give me your ideas. I''ll help turn them into clear, useful content that still sounds like you."**

That is a much more valuable service.

---', 'text', 2, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_modules (course_id, title, description, position) VALUES (v_course_id, 'Learning a Client''s Voice', 'Practical lessons from the AF Digital Hub Ghostwriting course.', 2) ON CONFLICT (course_id, position) DO UPDATE SET title=EXCLUDED.title, updated_at=now() RETURNING id INTO v_module_id;
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Voice Comes Before Vocabulary', 'voice-comes-before-vocabulary', 'A common beginner mistake is trying to copy a client''s favourite words.

Voice is bigger than vocabulary.

Pay attention to:

- Sentence length
- Pace
- Formality
- Humour
- Storytelling
- Emotional intensity
- Word choice
- Opinions
- Repeated expressions
- How the person starts and ends thoughts

Two people can use the same words and still sound completely different.

Your goal is not to imitate the client mechanically.

Your goal is to understand the person behind the words.

---', 'text', 1, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'The Voice Interview', 'the-voice-interview', 'Before writing important content for a new client, ask questions.

Useful questions include:

1. Who are you trying to reach?
2. What do you want people to understand?
3. What do you believe that your audience may disagree with?
4. What stories have shaped your perspective?
5. What words or expressions do you naturally use?
6. What kind of writing do you dislike?
7. Do you prefer direct, warm, professional, humorous, or conversational writing?
8. What should the reader feel after reading your content?
9. Are there subjects you never want to discuss?
10. Can you send me examples of things you have written or said publicly?

Do not treat the interview like an interrogation.

Have a conversation.

Often the best material appears when the client stops trying to sound professional.

---', 'text', 2, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_modules (course_id, title, description, position) VALUES (v_course_id, 'Turning Ideas Into Content', 'Practical lessons from the AF Digital Hub Ghostwriting course.', 3) ON CONFLICT (course_id, position) DO UPDATE SET title=EXCLUDED.title, updated_at=now() RETURNING id INTO v_module_id;
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Start With the Raw Material', 'start-with-the-raw-material', 'Clients rarely hand you perfect paragraphs.

You may receive:

- Voice notes
- WhatsApp messages
- Bullet points
- Meeting notes
- Recorded interviews
- Old articles
- Emails
- A rough outline
- A ten-minute conversation

Don''t panic.

Your first job is to find the useful ideas.

Separate the material into:

**What happened?**

**What does the client believe?**

**Why does it matter?**

**What should the reader do with it?**

Once those questions are answered, the writing becomes much easier.

---', 'text', 1, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Structure Before Sentences', 'structure-before-sentences', 'Don''t spend twenty minutes polishing the first paragraph when you don''t know where the piece is going.

Build the structure first.

For a simple article:

1. Opening idea
2. Problem
3. Story or example
4. Main lesson
5. Practical advice
6. Closing thought

For a social post:

1. Hook
2. Context
3. Main point
4. Example
5. Takeaway

For a longer project:

1. Purpose
2. Audience
3. Main themes
4. Chapters or sections
5. Supporting examples
6. Final message

Structure gives the writing somewhere to go.

---', 'text', 2, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_modules (course_id, title, description, position) VALUES (v_course_id, 'Writing Like a Human', 'Practical lessons from the AF Digital Hub Ghostwriting course.', 4) ON CONFLICT (course_id, position) DO UPDATE SET title=EXCLUDED.title, updated_at=now() RETURNING id INTO v_module_id;
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Don''t Polish the Life Out of It', 'don-t-polish-the-life-out-of-it', 'Professional does not mean lifeless.

Consider these two styles:

**"Effective communication is essential for the development of successful professional relationships."**

And:

**"People work better with you when they understand what you mean."**

The second sentence is simpler, but simplicity is often more powerful.

Good ghostwriting should feel like someone is talking to another human being.

Use specific examples.

Tell stories.

Allow personality into the writing.

Avoid filling every paragraph with impressive-sounding words.

---', 'text', 1, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Preserve the Client''s Meaning', 'preserve-the-client-s-meaning', 'Never change a client''s position just because you would express it differently.

If something is unclear, ask.

If something sounds inaccurate, flag it.

If a statement could create a serious misunderstanding, raise the concern.

A ghostwriter serves the client''s voice, but professional writing still requires care.

The goal is:

**clarity without distortion.**

---', 'text', 2, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_modules (course_id, title, description, position) VALUES (v_course_id, 'Ghostwriting Services You Can Sell', 'Practical lessons from the AF Digital Hub Ghostwriting course.', 5) ON CONFLICT (course_id, position) DO UPDATE SET title=EXCLUDED.title, updated_at=now() RETURNING id INTO v_module_id;
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Start With One Service', 'start-with-one-service', 'You do not need to offer everything.

A beginner could start with one service such as:

### LinkedIn Ghostwriting

You interview the client once a week and turn their ideas into several professional posts.

Or:

### Personal Brand Content

You help a founder or creator turn their experiences and ideas into regular social content.

Or:

### Ebook Ghostwriting

You help a client turn their knowledge into a structured digital book.

Or:

### Newsletter Ghostwriting

You turn the client''s weekly ideas into a useful email for their audience.

Start narrow.

Become good.

Expand later.

---', 'text', 1, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Building Your First Portfolio', 'building-your-first-portfolio', 'You do not need ten paying clients before you can show your writing ability.

Create sample projects.

For example:

- A fictional founder''s LinkedIn post
- A short business article
- A newsletter
- A personal story
- A sample ebook chapter

Be honest that these are samples.

Never present fictional work as paid client work.

A small portfolio that demonstrates range and quality is better than an impressive-looking portfolio built on claims you cannot prove.

---', 'text', 2, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_modules (course_id, title, description, position) VALUES (v_course_id, 'Working With Real Clients', 'Practical lessons from the AF Digital Hub Ghostwriting course.', 6) ON CONFLICT (course_id, position) DO UPDATE SET title=EXCLUDED.title, updated_at=now() RETURNING id INTO v_module_id;
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'The First Conversation', 'the-first-conversation', 'A professional first conversation should establish:

- What the client needs
- Who the audience is
- What the content is supposed to achieve
- How often content is needed
- How much research is required
- What approval process will be used
- How revisions work
- The deadline
- The price
- Ownership and confidentiality

Write the agreement down.

Do not rely on "we talked about it."

---', 'text', 1, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Revisions', 'revisions', 'Revisions are normal.

But unlimited revisions can turn a small project into an endless one.

A simple arrangement might include:

- First draft
- Client feedback
- One or two revision rounds
- Final approval

Ask clients to give specific feedback.

Instead of:

> "I don''t like it."

You want:

> "This sounds too formal. Make it more conversational."

Specific feedback saves time.

---', 'text', 2, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_modules (course_id, title, description, position) VALUES (v_course_id, 'Finding Ghostwriting Clients', 'Practical lessons from the AF Digital Hub Ghostwriting course.', 7) ON CONFLICT (course_id, position) DO UPDATE SET title=EXCLUDED.title, updated_at=now() RETURNING id INTO v_module_id;
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Look for People Who Already Have Something to Say', 'look-for-people-who-already-have-something-to-say', 'The best prospects are often not people with no ideas.

They are people with **too many ideas and too little time**.

Look for:

- Coaches
- Consultants
- Founders
- Executives
- Creators
- Speakers
- Authors
- Professionals building a personal brand

Study their public content before contacting them.

If you can identify a genuine gap, your message becomes more useful.

---', 'text', 1, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'A Better Outreach Message', 'a-better-outreach-message', 'Avoid:

> "Hello sir, I am a professional ghostwriter. Do you need my services?"

Try something more specific:

> "I came across your recent post about [topic]. You clearly have a lot of experience in this area. I noticed you don''t post very often, so I wondered if turning some of your existing ideas into regular content would be useful. I can send you a short sample in your style if you''d like."

It is personal, specific, and gives the person a reason to respond.

Never pretend you studied someone''s business when you did not.

---', 'text', 2, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_modules (course_id, title, description, position) VALUES (v_course_id, 'Pricing Your Work', 'Practical lessons from the AF Digital Hub Ghostwriting course.', 8) ON CONFLICT (course_id, position) DO UPDATE SET title=EXCLUDED.title, updated_at=now() RETURNING id INTO v_module_id;
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Price the Work, Not Just the Words', 'price-the-work-not-just-the-words', 'Ghostwriting is more than typing.

The work can include:

- Research
- Interviews
- Idea development
- Writing
- Editing
- Revisions
- Formatting
- Content planning
- Client communication

Consider the full workload before setting a price.

As a beginner, you may choose a smaller project to build experience.

For example:

**Starter package**
- 4 social posts
- One client interview
- One revision round

Then build larger packages as your skill and results improve.

Do not promise guaranteed followers, sales, or viral content.

You control the quality of your work.

You do not control the audience.

---', 'text', 1, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_modules (course_id, title, description, position) VALUES (v_course_id, 'Professional Standards', 'Practical lessons from the AF Digital Hub Ghostwriting course.', 9) ON CONFLICT (course_id, position) DO UPDATE SET title=EXCLUDED.title, updated_at=now() RETURNING id INTO v_module_id;
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Confidentiality', 'confidentiality', 'Some ghostwriting projects involve private information.

Treat client material carefully.

Do not:

- Share private drafts publicly.
- Publish client information without permission.
- Use confidential stories as portfolio pieces without approval.
- Forward private documents unnecessarily.

If confidentiality matters, put it in writing.

---', 'text', 1, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Ownership', 'ownership', 'Agree in advance about who owns the finished work.

A written agreement should make clear:

- What is being delivered.
- When ownership transfers.
- Whether the writer can use the work in a portfolio.
- Whether the client can edit or repurpose it.
- What happens if the project ends early.

When money and ownership are involved, clear agreements protect both sides.

---', 'text', 2, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();
  INSERT INTO course_modules (course_id, title, description, position) VALUES (v_course_id, 'Building a Real Ghostwriting Business', 'Practical lessons from the AF Digital Hub Ghostwriting course.', 10) ON CONFLICT (course_id, position) DO UPDATE SET title=EXCLUDED.title, updated_at=now() RETURNING id INTO v_module_id;
  INSERT INTO course_lessons (module_id, title, slug, content, lesson_type, position, is_preview) VALUES (v_module_id, 'Your Workflow', 'your-workflow', 'A simple professional workflow can look like this:

**1. Discover**

Understand the client and audience.

**2. Interview**

Collect ideas, stories, examples, and opinions.

**3. Organize**

Turn raw information into an outline.

**4. Draft**

Write in the client''s voice.

**5. Review**

Check facts, clarity, tone, and structure.

**6. Submit**

Give the client a clean draft.

**7. Revise**

Apply agreed feedback.

**8. Deliver**

Send the final version in the agreed format.

**9. Record**

Keep track of the project, payment, and permission to use the work.

A consistent process makes you look professional even when you are still growing.

---

# Final Project

Create a complete sample ghostwriting project.

Choose a fictional client.

Then create:

1. A one-page client profile.
2. A voice profile.
3. Ten interview questions.
4. A content outline.
5. A 700–1,000 word article in the client''s voice.
6. Three social posts based on the article.
7. A short client outreach message.
8. A simple service package.
9. A revision policy.
10. A delivery checklist.

The goal is not to pretend you already have years of experience.

The goal is to demonstrate that you understand the work.

---

# Ghostwriter''s Checklist

Before delivering a project, ask:

### Voice
- Does this sound like the client?
- Did I preserve their personality?
- Did I avoid forcing my own style into the work?

### Accuracy
- Did I preserve the client''s meaning?
- Did I verify factual claims where necessary?
- Did I flag anything uncertain?

### Structure
- Is the main idea clear?
- Does each section have a purpose?
- Does the ending feel complete?

### Readability
- Are the sentences clear?
- Did I remove unnecessary jargon?
- Does the writing sound natural when read aloud?

### Professionalism
- Did I meet the agreed deadline?
- Did I follow the revision terms?
- Did I handle private material appropriately?

---

# Final Note

Ghostwriting is not about hiding behind someone else''s name.

It is about becoming good enough at listening that another person''s ideas can pass through your hands without losing their identity.

The best ghostwriter is not the person who makes every sentence sound impressive.

It is the person who makes the reader forget there was a writer behind the scenes.

Learn to listen.

Learn to ask better questions.

Learn to write simply.

And, most importantly, learn to respect the voice you have been trusted to carry.

---

## Course Completion

**Course:** Ghostwriting: Turn Other People''s Ideas Into Words That Sound Like Them

**Platform:** AF Digital Hub

**Practical outcome:** Build a complete sample ghostwriting project and a professional starter service you can use when approaching potential clients.', 'text', 1, false) ON CONFLICT (module_id, position) DO UPDATE SET title=EXCLUDED.title, slug=EXCLUDED.slug, content=EXCLUDED.content, updated_at=now();

END $$;
COMMIT;