const express = require("express");
const router = express.Router();
const pool = require("../config/db");
const { requireAuth, requireRole } = require("../middleware/auth");
const { createNotification } = require("./notifications");

// Creator applies to a campaign
router.post("/", requireAuth, requireRole("creator"), async (req, res) => {
  try {
    const { campaign_id, proposed_price, pitch } = req.body;

    if (!campaign_id || !pitch) {
      return res.status(400).json({ error: "campaign_id and pitch are required" });
    }

    const campaignCheck = await pool.query("SELECT * FROM campaigns WHERE id = $1", [campaign_id]);
    if (campaignCheck.rows.length === 0) {
      return res.status(404).json({ error: "Campaign not found" });
    }

    // campaign_applications.creator_id references creator_profiles.id,
    // not users.id — look up the real creator profile ID first.
    const creatorProfile = await pool.query(
      "SELECT id FROM creator_profiles WHERE user_id = $1",
      [req.user.id]
    );
    if (creatorProfile.rows.length === 0) {
      return res.status(400).json({ error: "No creator profile found for this account" });
    }
    const creatorProfileId = creatorProfile.rows[0].id;

    const dupCheck = await pool.query(
      "SELECT * FROM campaign_applications WHERE campaign_id = $1 AND creator_id = $2",
      [campaign_id, creatorProfileId]
    );
    if (dupCheck.rows.length > 0) {
      return res.status(400).json({ error: "You already applied to this campaign" });
    }

    const result = await pool.query(
      `INSERT INTO campaign_applications (campaign_id, creator_id, proposed_price, pitch, status, created_at)
       VALUES ($1, $2, $3, $4, 'pending', NOW())
       RETURNING *`,
      [campaign_id, creatorProfileId, proposed_price || null, pitch]
    );

    const campaign = campaignCheck.rows[0];

    // campaign.business_id is a business_profiles.id — look up the
    // actual user_id behind it before creating a notification.
    const bizOwner = await pool.query(
      "SELECT user_id FROM business_profiles WHERE id = $1",
      [campaign.business_id]
    );
    if (bizOwner.rows.length > 0) {
      await createNotification(
        bizOwner.rows[0].user_id,
        "new_application",
        `You have a new application for "${campaign.title}"`
      );
    }

    res.status(201).json({ application: result.rows[0] });
  } catch (err) {
    console.error("Create application error:", err);
    res.status(500).json({ error: "Server error creating application", detail: err.message });
  }
});

// Business views all applications for one of their campaigns
router.get("/campaign/:campaignId", requireAuth, requireRole("business"), async (req, res) => {
  try {
    const campaignCheck = await pool.query("SELECT * FROM campaigns WHERE id = $1", [req.params.campaignId]);
    if (campaignCheck.rows.length === 0) {
      return res.status(404).json({ error: "Campaign not found" });
    }

    const bizProfile = await pool.query(
      "SELECT id FROM business_profiles WHERE user_id = $1",
      [req.user.id]
    );
    const ownBusinessId = bizProfile.rows[0] ? bizProfile.rows[0].id : null;

    if (campaignCheck.rows[0].business_id !== ownBusinessId) {
      return res.status(403).json({ error: "Not authorized to view these applications" });
    }

    const result = await pool.query(
      `SELECT a.*, cp.bio AS creator_bio, u.full_name AS creator_name, u.email AS creator_email
       FROM campaign_applications a
       JOIN creator_profiles cp ON a.creator_id = cp.id
       JOIN users u ON cp.user_id = u.id
       WHERE a.campaign_id = $1
       ORDER BY a.created_at DESC`,
      [req.params.campaignId]
    );

    res.json({ applications: result.rows });
  } catch (err) {
    console.error("List applications error:", err);
    res.status(500).json({ error: "Server error fetching applications" });
  }
});

// Creator views their own applications
router.get("/mine", requireAuth, requireRole("creator"), async (req, res) => {
  try {
    const creatorProfile = await pool.query(
      "SELECT id FROM creator_profiles WHERE user_id = $1",
      [req.user.id]
    );
    if (creatorProfile.rows.length === 0) {
      return res.json({ applications: [] });
    }
    const creatorProfileId = creatorProfile.rows[0].id;

    const result = await pool.query(
      `SELECT a.*, c.title AS campaign_title, c.budget
       FROM campaign_applications a
       JOIN campaigns c ON a.campaign_id = c.id
       WHERE a.creator_id = $1
       ORDER BY a.created_at DESC`,
      [creatorProfileId]
    );

    res.json({ applications: result.rows });
  } catch (err) {
    console.error("List my applications error:", err);
    res.status(500).json({ error: "Server error fetching your applications" });
  }
});

// Business accepts or rejects an application
router.put("/:id/status", requireAuth, requireRole("business"), async (req, res) => {
  try {
    const { status } = req.body;
    const validStatuses = ["accepted", "rejected"];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: "status must be 'accepted' or 'rejected'" });
    }

    const appCheck = await pool.query(
      `SELECT a.*, c.business_id, c.title
       FROM campaign_applications a
       JOIN campaigns c ON a.campaign_id = c.id
       WHERE a.id = $1`,
      [req.params.id]
    );

    if (appCheck.rows.length === 0) {
      return res.status(404).json({ error: "Application not found" });
    }

    const bizProfile = await pool.query(
      "SELECT id FROM business_profiles WHERE user_id = $1",
      [req.user.id]
    );
    const ownBusinessId = bizProfile.rows[0] ? bizProfile.rows[0].id : null;

    if (appCheck.rows[0].business_id !== ownBusinessId) {
      return res.status(403).json({ error: "Not authorized to update this application" });
    }

    const result = await pool.query(
      `UPDATE campaign_applications SET status = $1 WHERE id = $2 RETURNING *`,
      [status, req.params.id]
    );

    // app.creator_id here is a creator_profiles.id — look up the real
    // user_id before creating a notification.
    const app = appCheck.rows[0];
    const creatorOwner = await pool.query(
      "SELECT user_id FROM creator_profiles WHERE id = $1",
      [app.creator_id]
    );
    if (creatorOwner.rows.length > 0) {
      await createNotification(
        creatorOwner.rows[0].user_id,
        status === "accepted" ? "application_accepted" : "application_rejected",
        `Your application for "${app.title}" was ${status}`
      );
    }

    res.json({ application: result.rows[0] });
  } catch (err) {
    console.error("Update application status error:", err);
    res.status(500).json({ error: "Server error updating application status" });
  }
});

module.exports = router;
